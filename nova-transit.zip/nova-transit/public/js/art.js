/* Bus colours + garage skins. Shared by the canvas board (board.js) and the DOM previews (garage, Pro, map). */
(function () {
  const COLORS = [
    { base: '#ff5a64', light: '#ffa0a6', dark: '#b8283a', sym: 'circle',   key: 'c_coral' },
    { base: '#ffb020', light: '#ffd98a', dark: '#b87100', sym: 'triangle', key: 'c_amber' },
    { base: '#79d93a', light: '#bdf58c', dark: '#3f8f12', sym: 'square',   key: 'c_lime' },
    { base: '#19d3c5', light: '#8cf3ea', dark: '#0a8a86', sym: 'diamond',  key: 'c_aqua' },
    { base: '#3d8bff', light: '#9cc4ff', dark: '#1b4fc4', sym: 'star',     key: 'c_azure' },
    { base: '#9b6bff', light: '#cfb6ff', dark: '#5a34c7', sym: 'hex',      key: 'c_violet' },
    { base: '#ff5ea8', light: '#ffb0d4', dark: '#b81f68', sym: 'plus',     key: 'c_rose' },
  ];
  /* each skin maps a bus colour to concrete paint */
  const SKINS = {
    neon:    (C) => ({ top: '#2f3478', bot: '#0b0d2e', trim: C.base, stripe: C.base, winOff: C.base, winOn: C.light, wheel: C.base, hub: C.base, glow: true }),
    classic: (C) => ({ top: C.light, bot: C.base, trim: C.dark, stripe: '#ffffff', winOff: '#1d2a5a', winOn: '#e9f7ff', wheel: '#cfd6ee', hub: '#6b7399', glow: false }),
    glass:   (C) => ({ top: '#f6fbff', bot: '#a9c8e4', trim: C.base, stripe: C.base, winOff: C.dark, winOn: C.light, wheel: C.base, hub: '#ffffff', glow: false }),
    candy:   (C) => ({ top: '#ffffff', bot: C.light, trim: C.base, stripe: C.base, winOff: C.base, winOn: '#ffffff', wheel: C.dark, hub: '#ffffff', glow: false }),
    gold:    (C) => ({ top: '#fff0a8', bot: '#c98a0f', trim: C.base, stripe: C.base, winOff: '#6b4a00', winOn: C.light, wheel: '#7a4d00', hub: '#ffe680', glow: true }),
    galaxy:  (C) => ({ top: '#4a2a9a', bot: '#0a0524', trim: C.base, stripe: C.light, winOff: C.base, winOn: '#ffffff', wheel: C.light, hub: '#ff7be5', glow: true, sparkle: true }),
    aurora:  (C) => ({ top: '#0f5666', bot: '#04121d', trim: C.base, stripe: '#5dffb0', winOff: '#5dffb0', winOn: '#e9fff5', wheel: '#5dffb0', hub: C.base, glow: true, sparkle: true }),
  };
  const SKIN_NAMES = {
    tr: { neon: 'Neon', classic: 'Klasik', glass: 'Buz Camı', candy: 'Şeker', gold: 'Altın', galaxy: 'Galaksi', aurora: 'Aurora' },
    en: { neon: 'Neon', classic: 'Classic', glass: 'Ice Glass', candy: 'Candy', gold: 'Gold', galaxy: 'Galaxy', aurora: 'Aurora' },
  };
  let uid = 0;
  /** static SVG preview of a bus (side view) */
  function busSVG(ci, skinId, opts) {
    const C = COLORS[ci % COLORS.length], sk = (SKINS[skinId] || SKINS.neon)(C), id = 'b' + (uid++);
    const o = opts || {};
    return `<svg class="busart ${o.cls || ''}" viewBox="0 0 220 120" xmlns="http://www.w3.org/2000/svg"><defs>
<linearGradient id="${id}g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${sk.top}"/><stop offset="1" stop-color="${sk.bot}"/></linearGradient>
<filter id="${id}f" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="4"/></filter></defs>
<ellipse cx="110" cy="108" rx="92" ry="8" fill="${C.base}" opacity=".35"/>
${sk.glow ? `<rect x="16" y="22" width="188" height="72" rx="24" fill="none" stroke="${sk.trim}" stroke-width="8" opacity=".55" filter="url(#${id}f)"/>` : ''}
<rect x="16" y="22" width="188" height="72" rx="24" fill="url(#${id}g)" stroke="${sk.trim}" stroke-width="4"/>
<path d="M30 28 H188" stroke="#fff" stroke-opacity=".35" stroke-width="3" stroke-linecap="round"/>
<rect x="18" y="66" width="184" height="5" fill="${sk.stripe}" opacity=".9"/>
${[0, 1, 2, 3].map((i) => `<rect x="${30 + i * 31}" y="32" width="26" height="26" rx="8" fill="${i < (o.filled == null ? 3 : o.filled) ? sk.winOn : sk.winOff}" opacity="${i < (o.filled == null ? 3 : o.filled) ? 1 : 0.5}"/>${i < (o.filled == null ? 3 : o.filled) ? `<circle cx="${43 + i * 31}" cy="46" r="6" fill="#2a1647"/>` : ''}`).join('')}
<rect x="156" y="32" width="38" height="28" rx="10" fill="${C.light}" opacity=".85"/>
<circle cx="204" cy="76" r="5" fill="#fff6b0"/><circle cx="16" cy="76" r="3.5" fill="#ff2a4a"/>
${[56, 160].map((x) => `<circle cx="${x}" cy="96" r="14" fill="#101230" stroke="${sk.wheel}" stroke-width="4"/><circle cx="${x}" cy="96" r="5" fill="${sk.hub}"/>`).join('')}
${sk.sparkle ? '<circle cx="70" cy="30" r="1.6" fill="#fff"/><circle cx="130" cy="26" r="1.2" fill="#fff"/><circle cx="178" cy="40" r="1.4" fill="#fff"/><circle cx="96" cy="62" r="1.2" fill="#fff"/>' : ''}
</svg>`;
  }
  window.NT_ART = { COLORS, SKINS, SKIN_NAMES, busSVG };
})();
