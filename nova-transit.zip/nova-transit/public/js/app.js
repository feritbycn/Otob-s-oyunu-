/* Metro Mastery – app flow: splash, home, level map, game loop, shop, daily, Pro, garage, spin, missions, ranks, settings. */
(function () {
  const { $, $$, ic, fmt, html, sleep, settings, saveSettings, buzz, modal, toast, btn, flyCoins, confetti, rewarded, payment, countUp, mmss } = UI;
  const E = window.NovaEngine, ART = window.NT_ART;
  const S = { profile: null, config: null, view: null, run: null, level: null, live: { online: 0, playing: 0 }, screen: 'boot', busy: false, coinShown: 0, gemShown: 0, mapChapter: 0 };
  const lsGet = (k, d) => { try { const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } };
  const lsSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} };
  const BG = (id) => `url(assets/bg_${id}.svg)`;
  const dName = (d) => d.name[I18N.lang] || d.name.en;
  const propIcon = { reorder: 'shuffle', bay: 'bay', vip: 'vip', hint: 'hint', undo: 'undo' };
  const propName = (p) => T('prop_' + p);
  const MAIN_PROPS = ['hint', 'undo', 'reorder'];

  function show(name) {
    $$('.screen').forEach((s) => s.classList.toggle('active', s.id === 'screen-' + name));
    S.screen = name; window.NT_state = name === 'game' ? 'playing' : 'menu';
    API.sendState(window.NT_state, S.level ? S.level.n : 0);
  }
  const bootMsg = (k, pct) => { $('#boot-msg').textContent = T(k); if (pct != null) $('#boot-fill').style.width = pct + '%'; };
  const price = (pr) => (I18N.lang === 'tr' && pr.tl ? '₺' + (pr.tl / 100).toFixed(2).replace('.', ',') : '$' + (pr.cents / 100).toFixed(2));

  /* =================== boot =================== */
  async function boot() {
    const saved = localStorage.getItem('nt_lang');
    I18N.setLang(saved || I18N.detect());
    bootMsg('connecting', 15);
    for (let attempt = 0; ; attempt++) {
      try { const r = await API.register(I18N.lang); S.profile = r.profile; S.live = r.live; break; }
      catch (e) { bootMsg('offline_msg'); await sleep(Math.min(5000, 1200 + attempt * 600)); }
    }
    bootMsg('load_city', 55);
    try { S.config = await API.config(); } catch (e) { S.config = { daily: [], spin: { slices: [] }, products: [], propPrice: {}, districts: [], skins: [], missions: { chest: {} }, supply: {} }; }
    if (S.profile.lang && !saved) I18N.setLang(S.profile.lang);
    API.onLive((m) => { S.live = { online: m.online, playing: m.playing }; renderLive(); });
    API.connectWS();
    bootMsg('load_city', 100);
    await Promise.all(E.DISTRICTS.map((d) => new Promise((r) => { const i = new Image(); i.onload = i.onerror = r; i.src = `assets/bg_${d.id}.svg`; })));
    bindHome(); bindMap(); bindGame(); applyCbSetting();
    renderHome(); await sleep(350); show('home');
    autoPopups();
    setInterval(tick, 1000);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshProfile(); });
  }

  async function refreshProfile() { try { const r = await API.me(); S.profile = r.profile; S.live = r.live; renderHome(); renderLive(); } catch (e) {} }
  function setProfile(p, animate = true) {
    S.profile = p;
    if (animate && p.coins !== S.coinShown) countUp($('#hud-coins'), S.coinShown, p.coins); else $('#hud-coins').textContent = fmt(p.coins);
    if (animate && p.gems !== S.gemShown) countUp($('#hud-gems'), S.gemShown, p.gems); else $('#hud-gems').textContent = fmt(p.gems);
    S.coinShown = p.coins; S.gemShown = p.gems;
    renderHome(false); updateProps(); renderDiffLabel();
    if (S.view) S.view.setSkin(p.skin);
  }
  function autoPopups() {
    const p = S.profile;
    if (!p.daily.claimedToday) setTimeout(() => S.screen === 'home' && openDaily(), 450);
  }

  /* =================== home =================== */
  function renderHome() {
    const p = S.profile; if (!p) return;
    $('#hud-coins').textContent = fmt(p.coins); $('#hud-gems').textContent = fmt(p.gems); S.coinShown = p.coins; S.gemShown = p.gems;
    $('#play-level').textContent = T('level_n', { n: p.level });
    $('#badge-daily').hidden = p.daily.claimedToday;
    $('#badge-spin').hidden = !(p.spin.freeIn === 0 || p.spin.extra > 0);
    $('#badge-missions').hidden = !p.missions.some((m) => !m.claimed && m.progress >= m.goal) && !(p.missions.every((m) => m.claimed) && !p.chestClaimed);
    renderLive(); renderTimers(); renderDiffLabel();
  }
  function renderLive() {
    const l = S.live || { online: 0, playing: 0 };
    $('#live-text').textContent = `${fmt(l.online)} ${T('online')} · ${fmt(l.playing)} ${T('playing_now')}`;
  }
  function supplyLeft() { const p = S.profile; return Math.max(0, p.supply.readyIn - (Date.now() - (S._profileAt || Date.now())) / 1000); }
  function renderTimers() {
    const p = S.profile; if (!p) return;
    const el = $('#badge-supply'); const left = supplyLeft();
    el.textContent = left > 0 ? mmss(left) : '!'; el.className = 'badge' + (left > 0 ? ' timer' : '');
    const mg = $('#badge-map-gift'); if (mg) mg.hidden = left > 0;
  }
  function tick() { if (S.profile) renderTimers(); }
  function renderDiffLabel() {
    const p = S.profile; if (!p) return;
    const b = $('#btn-diff'); b.dataset.d = p.diff; $('#diff-label').textContent = T('d_' + p.diff);
  }

  function bindHome() {
    const go = (f) => () => { SFX.click(); f(); };
    $('#btn-play').onclick = go(() => startLevel(S.profile.level));
    $('#btn-map').onclick = go(openMap);
    $('#btn-shop').onclick = go(() => openShop('coins'));
    $('#btn-settings').onclick = $('#btn-settings2').onclick = go(openSettings);
    $('#btn-coins').onclick = go(() => openShop('coins'));
    $('#btn-gems').onclick = go(() => openShop('packs'));
    $('#btn-daily').onclick = go(openDaily);
    $('#btn-pro').onclick = go(openPro);
    $('#btn-garage').onclick = go(openGarage);
    $('#btn-missions').onclick = go(openMissions);
    $('#btn-spin').onclick = go(openSpin);
    $('#btn-supply').onclick = go(openSupply);
    $('#btn-rank').onclick = go(openRank);
  }

  /* =================== level map =================== */
  const MAPTHEME = {
    harbor:  { a: '#5bc24a', b: '#2f8a3a', water: '#2d9bd6', tree: '#2a7a34' },
    oldtown: { a: '#d9b56a', b: '#a8803c', water: '#5a8fb5', tree: '#7a8a3a' },
    neon:    { a: '#4b2f8a', b: '#251552', water: '#c2186f', tree: '#7b4fd8' },
    gardens: { a: '#4fd6a6', b: '#1f8f78', water: '#3bb5d8', tree: '#1f9a6a' },
    orbit:   { a: '#2c3f9e', b: '#121a5c', water: '#6a2fb0', tree: '#4a5fd8' },
    aurora:  { a: '#1c8f8a', b: '#0b3f52', water: '#6b3fd8', tree: '#2fc7a0' },
  };
  function bindMap() {
    $('#map-back').onclick = () => { SFX.click(); show('home'); renderHome(); };
    $('#map-prev').onclick = () => { SFX.click(); renderMap(S.mapChapter - 1); };
    $('#map-next').onclick = () => { SFX.click(); renderMap(S.mapChapter + 1); };
    $('#map-gift').onclick = () => { SFX.click(); openSupply(); };
    $('#btn-diff').onclick = () => { SFX.click(); openDifficulty(); };
    $('#mapscroll').addEventListener('click', (e) => {
      const g = e.target.closest('.node'); if (!g) return;
      const n = +g.dataset.n; if (n > S.profile.level) { toast(T('toast_locked_level'), 'bad'); SFX.deny && SFX.deny(); return; }
      SFX.click(); startLevel(n);
    });
  }
  function openMap() { show('map'); renderMap(E.districtOf(S.profile.level)); renderTimers(); }
  function renderMap(ci) {
    const p = S.profile, maxC = E.districtOf(p.level);
    ci = Math.max(0, Math.min(maxC, ci)); S.mapChapter = ci;
    const d = E.DISTRICTS[ci], th = MAPTHEME[d.id];
    $('#map-chapter').textContent = `${T('chapter')} ${ci + 1}`; $('#map-name').textContent = dName(d);
    $('#map-prev').disabled = ci === 0; $('#map-next').disabled = ci >= maxC;
    const to = d.to === Infinity ? Math.max(d.from + 39, p.level + 8) : d.to, count = to - d.from + 1;
    const W = 400, step = 108, padTop = 150, padBot = 130, H = padTop + (count - 1) * step + padBot;
    const pt = (i) => ({ x: 200 + Math.sin(i * 0.95 + ci) * 104, y: H - padBot - i * step });
    const pts = Array.from({ length: count }, (_, i) => pt(i));
    let path = `M${pts[0].x} ${pts[0].y + 90}`; path += ` L${pts[0].x} ${pts[0].y}`;
    for (let i = 1; i < pts.length; i++) { const a = pts[i - 1], b = pts[i], my = (a.y + b.y) / 2; path += ` C${a.x} ${my} ${b.x} ${my} ${b.x} ${b.y}`; }
    path += ` L${pts[pts.length - 1].x} ${pts[pts.length - 1].y - 120}`;
    const rnd = E.mulberry32(ci * 99 + 7); let deco = '';
    for (let k = 0; k < Math.round(H / 42); k++) {
      const x = rnd() < 0.5 ? 10 + rnd() * 80 : 310 + rnd() * 80, y = 40 + rnd() * (H - 80), r = 12 + rnd() * 16;
      deco += `<circle cx="${x.toFixed(0)}" cy="${y.toFixed(0)}" r="${r.toFixed(0)}" fill="${th.tree}"/><circle cx="${(x - r * 0.25).toFixed(0)}" cy="${(y - r * 0.25).toFixed(0)}" r="${(r * 0.55).toFixed(0)}" fill="#fff" opacity=".12"/>`;
    }
    for (let k = 0; k < Math.round(H / 260); k++) { const x = k % 2 ? 330 : 14, y = 120 + rnd() * (H - 300); deco += `<g transform="translate(${x} ${y.toFixed(0)})"><rect width="52" height="40" rx="4" fill="#f3e9d4"/><polygon points="-4,2 26,-22 56,2" fill="#d9573a"/><rect x="10" y="14" width="10" height="26" fill="#6b4a2a"/><rect x="30" y="12" width="12" height="12" fill="#7fd6ff"/></g>`; }
    const water = `<path d="M${W} 0 V${H} H${W - 70} C${W - 140} ${H * 0.8} ${W - 20} ${H * 0.6} ${W - 80} ${H * 0.45} S${W - 30} ${H * 0.15} ${W - 90} 0Z" fill="${th.water}" opacity=".85"/>`;
    let nodes = '';
    for (let i = 0; i < count; i++) {
      const n = d.from + i, c = pts[i], st = p.levelStars[n] || 0, cur = n === p.level, locked = n > p.level, done = n < p.level || st > 0;
      const stars = done ? [0, 1, 2].map((s) => `<use href="assets/icons.svg#i-${s < st ? 'star' : 'starOff'}" x="${c.x - 30 + s * 20}" y="${c.y + 33 - (s === 1 ? 0 : 5) + (s === 1 ? 4 : 0) - 4}" width="20" height="20"/>`).join('') : '';
      if (cur) nodes += `<g class="node" data-n="${n}"><circle cx="${c.x}" cy="${c.y}" r="48" fill="#ffcf4a" opacity=".25"><animate attributeName="r" values="40;54;40" dur="1.8s" repeatCount="indefinite"/></circle><circle cx="${c.x}" cy="${c.y}" r="38" fill="#b86a00"/><circle cx="${c.x}" cy="${c.y}" r="34" fill="url(#gcur)" stroke="#fff3b0" stroke-width="3"/><text x="${c.x}" y="${c.y + 12}" text-anchor="middle" font-size="34" fill="#5a3200">${n}</text><use href="assets/icons.svg#i-crown" x="${c.x - 17}" y="${c.y - 62}" width="34" height="34"/></g>`;
      else if (locked) nodes += `<g class="node" data-n="${n}"><circle cx="${c.x}" cy="${c.y}" r="30" fill="#3d4257" stroke="#2a2e40" stroke-width="4"/><circle cx="${c.x}" cy="${c.y}" r="25" fill="#5a607a"/><text x="${c.x}" y="${c.y + 8}" text-anchor="middle" font-size="22" fill="#c5cae0">${n}</text></g>`;
      else nodes += `<g class="node" data-n="${n}"><circle cx="${c.x}" cy="${c.y}" r="32" fill="#10205a" stroke="#d7e4ff" stroke-width="3"/><circle cx="${c.x}" cy="${c.y}" r="27" fill="url(#gdone)"/><text x="${c.x}" y="${c.y + 10}" text-anchor="middle" font-size="28" fill="#fff" stroke="#0d2a80" stroke-width="3" paint-order="stroke">${n}</text>${stars}</g>`;
    }
    $('#mapscroll').innerHTML = `<svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="xMidYMin slice" style="height:${H * (document.getElementById('mapscroll').clientWidth || 400) / W}px">
      <defs><linearGradient id="gm" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${th.a}"/><stop offset="1" stop-color="${th.b}"/></linearGradient>
      <linearGradient id="gcur" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff29a"/><stop offset="1" stop-color="#ff9f1a"/></linearGradient>
      <linearGradient id="gdone" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#5da4ff"/><stop offset="1" stop-color="#2a55e0"/></linearGradient></defs>
      <rect width="${W}" height="${H}" fill="url(#gm)"/>${water}${deco}
      <path d="${path}" fill="none" stroke="#1f2437" stroke-width="86" stroke-linecap="round" stroke-linejoin="round"/>
      <path d="${path}" fill="none" stroke="#3b4260" stroke-width="74" stroke-linecap="round" stroke-linejoin="round"/>
      <path d="${path}" fill="none" stroke="#fff" stroke-opacity=".75" stroke-width="4" stroke-dasharray="16 18" stroke-linecap="round"/>
      ${nodes}</svg>`;
    const sc = $('#mapscroll'), k = sc.clientWidth / W;
    const idx = Math.max(0, Math.min(count - 1, p.level - d.from));
    sc.scrollTop = Math.max(0, pts[idx].y * k - sc.clientHeight * 0.55);
  }

  function openDifficulty() {
    const p = S.profile;
    const m = modal({ title: T('diff_title'), cls: 'wide', body: '' });
    const draw = () => {
      m.setBody(E.DIFFS.map((df, i) => {
        const stars = [0, 1, 2].map((s) => ic(s < Math.min(3, i + 1) ? 'star' : 'starOff')).join('');
        return `<button class="diffcard d${i} ${S.profile.diff === i ? 'sel' : ''}" data-d="${i}"><span class="di">${ART.busSVG([2, 4, 1, 5][i], 'classic', { filled: 3 })}</span>
          <span class="dt"><b>${T('d_' + i)}</b><span class="st">${stars}</span><small>${T('d_' + i + '_d')}</small><small>${T('reward_x', { n: df.reward })}</small></span></button>`;
      }).join(''));
      $$('.diffcard', m.body).forEach((b) => (b.onclick = async () => {
        SFX.click(); const d = +b.dataset.d;
        try { const r = await API.setProfile({ diff: d }); setProfile(r.profile, false); } catch (e) { toast(T('toast_err'), 'bad'); return; }
        draw(); setTimeout(() => m.close(), 220);
      }));
    };
    draw();
  }

  /* =================== game =================== */
  function bindGame() {
    S.view = new GameView($('#cv'), { onEnd: onGameEnd, onDeny: onDeny, onMove: onMove, onBoard: onBoard });
    $('#btn-pause').onclick = () => { SFX.click(); openPause(); };
    $$('#props .prop').forEach((b) => (b.onclick = () => onProp(b.dataset.prop)));
  }
  function applyCbSetting() { S.view.setColorblind(settings.cb); }
  function onDeny(reason) {
    buzz(40);
    if (reason === 'blocked') toast(T('toast_blocked'), 'bad');
    else if (reason === 'full') toast(T('toast_full'), 'bad');
    else if (reason === 'locked') toast(T('toast_locked'), 'bad');
  }
  function renderHudStars() {
    const st = S.view && S.view.game ? S.view.game.stars() : 3;
    $('#hud-stars').innerHTML = [1, 2, 3].map((i) => ic(i <= st ? 'star' : 'starOff')).join('');
  }
  function renderCount() { const tot = S.level ? S.level.total : 0; $('#hud-delivered').textContent = `${Math.min(S.view.shown, tot)}/${tot}`; }
  function onMove() { hideCoach(); renderHudStars(); renderCount(); }
  function onBoard() { renderCount(); }
  function hideCoach() { const c = $('#coach'); if (!c.hidden) c.hidden = true; }
  function coach(key) { const c = $('#coach'); c.textContent = T(key); c.hidden = false; clearTimeout(coach.t); coach.t = setTimeout(hideCoach, 9000); }

  async function startLevel(n) {
    if (S.busy) return; S.busy = true;
    try {
      const r = await API.startLevel(n, S.profile.diff);
      S.run = { id: r.runId, attempt: r.attempt, start: Date.now() }; S.level = r.level; setProfile(r.profile, false);
      const d = E.DISTRICTS[r.level.district];
      $('#game-bg').style.backgroundImage = BG(d.id);
      $('#hud-level').textContent = T('level_n', { n });
      show('game');
      await sleep(60);
      S.view.setColorblind(settings.cb); S.view.setSkin(S.profile.skin);
      S.view.load(r.level);
      if (r.freeBay) S.view.applyProp('bay');
      renderHudStars(); renderCount(); updateProps();
      const tutKey = { 1: 'tut1', 2: 'tut2', 3: 'tut3', 4: 'tut4' }[n];
      const seenTips = lsGet('nt_tips', {});
      if (tutKey && !seenTips[tutKey]) { seenTips[tutKey] = 1; lsSet('nt_tips', seenTips); coach(tutKey); }
      else if (r.level.pods.some((p) => p.kind === 'mystery') && !seenTips.tut_mystery) { seenTips.tut_mystery = 1; lsSet('nt_tips', seenTips); coach('tut_mystery'); }
      else if (r.level.pods.some((p) => p.kind === 'lock') && !seenTips.tut_lock) { seenTips.tut_lock = 1; lsSet('nt_tips', seenTips); coach('tut_lock'); }
      else hideCoach();
      if (r.level.hard) toast('⚡ ' + T('boss'));
    } catch (e) {
      if (e.code === 'level_locked') { toast(T('toast_err'), 'bad'); refreshProfile(); } else toast(T('toast_err'), 'bad');
    } finally { S.busy = false; }
  }

  function updateProps() {
    const p = S.profile; if (!p) return;
    $$('#props .prop').forEach((b) => {
      const k = b.dataset.prop, n = p.props[k] || 0, c = $('.cnt', b);
      if (k === 'hint' && p.pro) { c.textContent = '∞'; c.classList.remove('ad'); b.classList.remove('empty'); }
      else if (n > 0) { c.textContent = n; c.classList.remove('ad'); b.classList.remove('empty'); }
      else { c.textContent = '▶'; c.classList.add('ad'); b.classList.add('empty'); }
    });
  }

  async function onProp(name) {
    if (!S.view.game || S.view.ended || S.view.paused || S.busy) return;
    const p = S.profile;
    if (name === 'undo' && !S.view.canUndo()) { toast(T('toast_undo_none'), 'bad'); return; }
    if (name === 'reorder' && !S.view.canUse('reorder')) { toast(T('toast_busy'), 'bad'); return; }
    if (!(name === 'hint' && p.pro) && (p.props[name] || 0) < 1) { openGetProp(name); return; }
    S.busy = true;
    try {
      const r = await API.useProp(S.run.id, name); setProfile(r.profile, false);
      if (name === 'hint') { const ok = S.view.hint(); toast(ok ? T('toast_hint') : T('toast_nohint'), ok ? 'good' : 'bad'); }
      else if (name === 'undo') { S.view.undo(); SFX.pop(); toast(T('toast_undo'), 'good'); }
      else { S.view.applyProp(name); SFX.pop(); }
    } catch (e) { toast(e.code === 'no_stock' ? T('toast_nocoins') : T('toast_err'), 'bad'); refreshProfile(); }
    finally { S.busy = false; }
  }
  function openGetProp(name) {
    S.view.paused = true;
    const pr = S.config.propPrice[name];
    const m = modal({ title: propName(name), cls: 'center', onClose: () => { S.view.paused = false; },
      body: `<div class="card"><div class="ci">${ic(propIcon[name])}</div><div class="ct"><b>${propName(name)}</b><small>${T('prop_' + name + '_d')}</small></div></div>`,
      foot: [
        btn(`${ic('play')} ${T('get_prop_ad')}`, 'green', async () => { const r = await rewarded('free_prop', { prop: name, label: propName(name) + ' +1' }); if (r) { setProfile(r.profile); toast(`${T('toast_got')} ${propName(name)} +1`, 'good'); m.close(); } }),
        btn(`${ic('coin')} ${fmt(pr)} · ${T('get_prop_coin')}`, 'gold', async () => {
          if (S.profile.coins < pr) { toast(T('toast_nocoins'), 'bad'); return; }
          try { const r = await API.buyProp(name); setProfile(r.profile); toast(`${T('toast_got')} ${propName(name)} +1`, 'good'); m.close(); } catch (e) { toast(T('toast_err'), 'bad'); }
        }),
      ] });
  }

  function openPause() {
    S.view.paused = true;
    const m = modal({ title: T('pause'), cls: 'center', closable: false,
      body: `<div class="muted" style="padding:6px 0 4px">${T('level_n', { n: S.level.n })} · ${T('d_' + S.level.diff)}</div>`,
      foot: [btn(T('resume'), 'green', () => { S.view.paused = false; m.close(); }),
        btn(T('restart'), 'ghost', async () => { m.close(); await finishRun('quit'); startLevel(S.level.n); }),
        btn(T('m_map'), 'ghost', async () => { m.close(); await finishRun('quit'); openMap(); }),
        btn(T('quit'), 'ghost', async () => { m.close(); await finishRun('quit'); goHome(); })] });
  }
  async function finishRun(result, extra) {
    if (!S.run) return null;
    const run = S.run; S.run = null;
    try { const r = await API.finishLevel({ runId: run.id, result, actions: S.view.actions, durationMs: Date.now() - run.start, ...(extra || {}) }); setProfile(r.profile, false); return r; }
    catch (e) { if (e.code === 'invalid_run') toast('⚠️ ' + e.code, 'bad'); await refreshProfile(); return null; }
  }
  function goHome() { show('home'); renderHome(); }

  /* ---- end of level ---- */
  async function onGameEnd(status, info) { if (status === 'win') await onWin(info); else onLose(info); }
  async function onWin() {
    SFX.win(); buzz([30, 40, 60]); confetti();
    const run = S.run; const res = await finishRun('win');
    if (!res) { goHome(); return; }
    const level = S.level, d = E.DISTRICTS[level.district];
    const reward = res.reward;
    const stars = `<div class="stars">${[1, 2, 3].map((i) => ic(i <= res.stars ? 'star' : 'starOff')).join('')}</div>`;
    const gemLine = res.gems ? `<div class="reward-line" style="font-size:26px;color:#7cd6ff">${ic('gem')} +${res.gems} <small style="font-size:13px;color:#b9c0ee">${T('first_clear')}</small></div>` : '';
    const m = modal({ title: T('win'), closable: false, cls: 'center', body: `${stars}${level.hard ? `<div class="muted">⚡ ${T('boss')}</div>` : ''}<div class="muted">${T('earned')}</div><div class="reward-line">${ic('coin')} +<span id="rw">${fmt(reward)}</span></div>${gemLine}`, foot: [] });
    const x2 = btn(`${ic('play')} ${T('x2')} <small style="display:inline;margin-left:4px">+${fmt(reward)}</small>`, 'green', async () => {
      x2.disabled = true;
      const r = await rewarded('double_reward', { runId: run.id, label: `+${fmt(reward)} ${ic('coin')}` });
      if (r) { setProfile(r.profile); const rw = $('#rw', m.el); countUp(rw, reward, reward * 2, 700); flyCoins(rw, 10); x2.remove(); } else x2.disabled = false;
    });
    const next = btn(`${T('next')} ›`, 'gold', async () => { m.close(); await afterWin(level, d); });
    const map = btn(T('m_map'), 'ghost', () => { m.close(); openMap(); });
    m.foot.append(x2, next, map);
    flyCoins($('.reward-line', m.el), 8);
  }
  async function afterWin(level, d) {
    if (level.n === d.to) { confetti(3000); toast('🏙️ ' + T('chapter') + ' ✓ ' + dName(d), 'good'); await sleep(900); }
    try { const r = await API.interstitial(); if (r.show) { API.sendState('ad'); await UI.AdProvider.showInterstitial(); } } catch (e) {}
    startLevel(S.profile.level);
  }
  function onLose() {
    SFX.lose(); buzz(120);
    const p = S.profile, pr = S.config.propPrice.bay;
    const m = modal({ title: T('lose'), closable: false, cls: 'center', body: `<div class="muted" style="margin-bottom:8px">${T('lose_sub')}</div><div style="font-size:68px;line-height:1">😮</div>`, foot: [] });
    const revive = btn(`${ic('play')} ${T('revive')}<small style="display:block;letter-spacing:0;font-size:12px;opacity:.9">${T('revive_sub')}</small>`, 'green', async () => {
      revive.disabled = true;
      const r = await rewarded('revive', { runId: S.run.id, label: T('revive') });
      if (r) { m.close(); S.view.applyRevive(); toast('+1 ' + T('p_bay'), 'good'); } else revive.disabled = false;
    });
    const undo = btn(`${ic('undo')} ${T('p_undo')} · ×${p.props.undo || 0}`, 'gold', async () => {
      if (!(p.props.undo > 0) || !S.view.canUndo()) { toast(T('toast_undo_none'), 'bad'); return; }
      try { const r = await API.useProp(S.run.id, 'undo'); setProfile(r.profile, false); m.close(); S.view.undo(); } catch (e) { toast(T('toast_err'), 'bad'); }
    });
    const buyBay = btn(`${ic('bay')} ${T('buy_bay')} · ${ic('coin')} ${fmt(pr)}`, 'gold', async () => {
      if (p.props.bay > 0) { try { const r = await API.useProp(S.run.id, 'bay'); setProfile(r.profile, false); m.close(); S.view.applyProp('bay'); } catch (e) { toast(T('toast_err'), 'bad'); } return; }
      if (S.profile.coins < pr) { toast(T('toast_nocoins'), 'bad'); return; }
      try { await API.buyProp('bay'); const r = await API.useProp(S.run.id, 'bay'); setProfile(r.profile, false); m.close(); S.view.applyProp('bay'); } catch (e) { toast(T('toast_err'), 'bad'); }
    });
    const retry = btn(T('retry'), 'ghost', async () => { m.close(); await finishRun('lose'); startLevel(S.level.n); });
    const home = btn(T('quit'), 'ghost', async () => { m.close(); await finishRun('lose'); goHome(); });
    m.foot.append(revive, undo, buyBay, retry, home);
  }

  /* =================== daily =================== */
  function rewardIcon(r) { return r.prop ? ic(propIcon[r.prop]) : r.gems && !r.coins ? ic('gem') : ic('coin'); }
  function rewardText(r) {
    const a = [];
    if (r.coins) a.push(fmt(r.coins));
    if (r.gems) a.push(`${r.coins ? '' : ''}${fmt(r.gems)}`);
    if (r.prop) a.push('×' + r.n);
    return a.join(' + ');
  }
  function openDaily() {
    const cfg = S.config.daily;
    const m = modal({ title: T('t_daily'), cls: 'wide', body: '' });
    const draw = () => {
      const pr = S.profile, next = pr.daily.claimedToday ? pr.daily.day : pr.daily.next;
      const stateOf = (i) => ((i + 1 === next && !pr.daily.claimedToday) ? 'cur' : ((i + 1 <= pr.daily.day && pr.daily.claimedToday) || (i + 1 < next)) ? 'done' : '');
      const cells = cfg.slice(0, 6).map((r, i) => `<div class="dcell ${stateOf(i)}"><small>${T('daily_day_n', { n: i + 1 })}</small>${rewardIcon(r)}<div>${rewardText(r)}</div></div>`).join('');
      const r7 = cfg[6];
      const d7 = `<div class="dday7 ${stateOf(6)}"><div class="l"><small>${T('daily_day_n', { n: 7 })}</small><div class="amts">${r7.coins ? `<span>${ic('coin')} ${fmt(r7.coins)}</span>` : ''}${r7.gems ? `<span>${ic('gem')} ${fmt(r7.gems)}</span>` : ''}</div></div>${ic('chest', 'big')}</div>`;
      m.setBody(`<p class="sub">${T('daily_sub')}</p><div class="daily3">${cells}${d7}</div>`);
      m.foot.innerHTML = ''; m.foot.style.display = '';
      if (!pr.daily.claimedToday) m.foot.appendChild(btn(T('claim_reward'), 'green', async (b) => {
        b.disabled = true;
        try { const r = await API.dailyClaim(); setProfile(r.profile); SFX.coin(); flyCoins(m.body, 8); draw(); } catch (e) { toast(T('toast_err'), 'bad'); }
      }));
      else {
        if (!pr.daily.doubled) m.foot.appendChild(btn(`${ic('play')} ${T('daily_x2')}`, 'green', async (b) => {
          b.disabled = true; const r = await rewarded('daily_double', { label: T('daily_x2') }); if (r) { setProfile(r.profile); flyCoins(m.body, 8); draw(); } else b.disabled = false;
        }));
        m.foot.appendChild(html(`<div class="muted">${T('daily_done')}</div>`));
      }
    };
    draw();
  }

  /* =================== supplies (free gift) =================== */
  function openSupply() {
    const cfg = S.config.supply;
    const m = modal({ title: T('supply_title'), cls: 'center', body: '' });
    let iv;
    const draw = () => {
      const left = supplyLeft();
      m.setBody(`<div style="font-size:84px;line-height:1.1">${ic('chest', '')}</div><div class="reward-line" style="font-size:30px">${ic('coin')} ${fmt(cfg.coins)}</div>${left > 0 ? `<p class="muted">${T('supply_wait')} <b id="sleft">${mmss(left)}</b></p>` : ''}`);
      $('.ic', m.body).style.cssText = 'width:96px;height:96px';
      m.foot.innerHTML = ''; m.foot.style.display = '';
      const free = btn(T('supply_free'), 'gold', async () => { try { const r = await API.supplyClaim(); setProfile(r.profile); flyCoins(m.body, 6); await sleep(400); m.close(); } catch (e) { toast(T('ad_cooldown'), 'bad'); } });
      const ad = btn(`${ic('play')} ${T('supply_ad')} · ${fmt(cfg.coins * cfg.adMultiplier)}`, 'green', async () => { const r = await rewarded('supply', { label: `+${fmt(cfg.coins * cfg.adMultiplier)} ${ic('coin')}` }); if (r) { setProfile(r.profile); flyCoins(m.body, 10); await sleep(500); m.close(); } });
      if (left > 0) { free.disabled = true; ad.disabled = true; }
      m.foot.append(ad, free);
    };
    draw(); iv = setInterval(() => { if (!m.el.isConnected) return clearInterval(iv); const left = supplyLeft(); const el = $('#sleft', m.el); if (el) el.textContent = mmss(left); if (left <= 0 && el) draw(); }, 1000);
  }

  /* =================== spin =================== */
  const SLICE_COLORS = ['#ff5a64', '#ffb020', '#79d93a', '#19d3c5', '#3d8bff', '#9b6bff', '#ff5ea8', '#ff8a3d'];
  function wheelSVG(slices) {
    const n = slices.length, a = 360 / n, R = 140;
    const pt = (deg, r) => { const t = (deg - 90) * Math.PI / 180; return [150 + r * Math.cos(t), 150 + r * Math.sin(t)]; };
    let s = `<svg id="wheel" viewBox="0 0 300 300"><circle cx="150" cy="150" r="148" fill="#2a1f66" stroke="#fff" stroke-width="4"/>`;
    slices.forEach((sl, i) => {
      const [x1, y1] = pt(i * a, R), [x2, y2] = pt((i + 1) * a, R);
      s += `<path d="M150 150 L${x1} ${y1} A${R} ${R} 0 0 1 ${x2} ${y2}Z" fill="${SLICE_COLORS[i % SLICE_COLORS.length]}" stroke="#fff" stroke-width="2"/>`;
      const mid = i * a + a / 2, [tx, ty] = pt(mid, 98);
      const txt = (t) => `<text y="30" text-anchor="middle" font-size="22" font-weight="800" fill="#fff" stroke="#0006" stroke-width="3" paint-order="stroke" font-family="Baloo 2,system-ui,sans-serif">${t}</text>`;
      const label = sl.coins ? `${txt(sl.coins)}<use href="assets/icons.svg#i-coin" x="-14" y="-18" width="28" height="28"/>`
        : sl.gems ? `${txt(sl.gems)}<use href="assets/icons.svg#i-gem" x="-14" y="-18" width="28" height="28"/>`
        : `<use href="assets/icons.svg#i-${propIcon[sl.prop]}" x="-16" y="-20" width="32" height="32"/>${txt('×' + sl.n)}`;
      s += `<g transform="translate(${tx} ${ty}) rotate(${mid})">${label}</g>`;
    });
    s += `<circle cx="150" cy="150" r="22" fill="#fff"/><circle cx="150" cy="150" r="14" fill="#ff5ea8"/></svg>`;
    return s;
  }
  function openSpin() {
    const slices = S.config.spin.slices; let rot = 0, spinning = false;
    const m = modal({ title: T('spin_title'), cls: 'center', body: `<div class="wheel-wrap"><div class="pointer"></div>${wheelSVG(slices)}</div><div id="spin-info" class="muted"></div>`, foot: [] });
    const info = $('#spin-info', m.el);
    const draw = () => {
      const p = S.profile; const left = Math.max(0, p.spin.freeIn - (Date.now() - (S._profileAt || Date.now())) / 1000);
      m.foot.innerHTML = '';
      if (left <= 0) m.foot.appendChild(btn(T('spin_free'), 'gold', () => go('free')));
      else if (p.spin.extra > 0) m.foot.appendChild(btn(`${T('spin_extra')} (${p.spin.extra})`, 'gold', () => go('extra')));
      else m.foot.appendChild(btn(`${ic('play')} ${T('spin_ad')}`, 'green', async () => { const r = await rewarded('spin', { label: T('spin_title') }); if (r) { setProfile(r.profile); draw(); } }));
      info.textContent = left > 0 ? `${T('spin_next')} ${mmss(left)}` : '';
    };
    async function go(mode) {
      if (spinning) return; spinning = true; m.foot.innerHTML = '';
      try {
        const r = await API.spin(mode); const sl = r.slice, idx = slices.findIndex((x) => x.id === sl.id);
        const a = 360 / slices.length; rot += 360 * 6 + ((-(idx * a + a / 2) - rot) % 360 + 360) % 360;
        $('#wheel', m.el).style.transform = `rotate(${rot}deg)`;
        const tk = setInterval(() => SFX.spin(), 120);
        await sleep(4300); clearInterval(tk);
        SFX.win(); confetti(1800); setProfile(r.profile); flyCoins($('.wheel-wrap', m.el), sl.coins ? 10 : 3);
        info.innerHTML = `${T('spin_won')} ${sl.coins ? `${ic('coin')} ${fmt(sl.coins)}` : sl.gems ? `${ic('gem')} ${fmt(sl.gems)}` : `${ic(propIcon[sl.prop])} ×${sl.n}`}`;
      } catch (e) { toast(T('toast_err'), 'bad'); }
      spinning = false; setTimeout(draw, 1400);
    }
    draw();
    const iv = setInterval(() => { if (!m.el.isConnected) return clearInterval(iv); if (!spinning) draw(); }, 1000);
  }

  /* =================== missions =================== */
  function missionText(m) { const col = m.color != null ? T(NT_COLORS[m.color].key) : ''; return T('m_' + m.id, { n: m.goal, c: col }); }
  function rewardLabel(r) { return r.prop ? '×' + r.n + ' ' + propName(r.prop) : (r.gems ? '+' + fmt(r.gems) + ' ' + T('gems') : '+' + fmt(r.coins)); }
  function openMissions() {
    const m = modal({ title: T('missions_title'), body: '' });
    const draw = () => {
      const p = S.profile; const allClaimed = p.missions.every((x) => x.claimed);
      const rows = p.missions.map((x, i) => {
        const done = x.progress >= x.goal;
        return `<div class="mission"><div class="ci" style="width:48px;height:48px;border-radius:14px;background:rgba(255,255,255,.1);display:grid;place-items:center">${rewardIcon(x.reward)}</div>
          <div class="mt"><b>${missionText(x)}</b><div class="mbar"><i style="width:${Math.min(100, (x.progress / x.goal) * 100)}%"></i></div><div class="mp">${x.progress}/${x.goal} · ${rewardLabel(x.reward)}</div></div>
          <button class="btn ${x.claimed ? 'ghost' : done ? 'green' : 'ghost'}" data-i="${i}" ${(!done || x.claimed) ? 'disabled' : ''} style="min-height:42px;padding:0 14px;font-size:16px">${x.claimed ? '✓' : T('claim')}</button></div>`;
      }).join('');
      const ch = S.config.missions.chest;
      m.setBody(`${rows}<div class="mission" style="border-color:var(--gold)"><div class="ci" style="width:48px;height:48px;display:grid;place-items:center">${ic('chest')}</div><div class="mt"><b>${T('mission_chest')}</b><div class="mp">${T('mission_chest_note')}<br>+${fmt(ch.coins)} ${ic('coin')} · +${ch.gems} ${ic('gem')}</div></div><button class="btn gold" id="chest" ${allClaimed && !p.chestClaimed ? '' : 'disabled'} style="min-height:42px;padding:0 14px;font-size:16px">${p.chestClaimed ? '✓' : T('claim')}</button></div><p class="muted" style="text-align:center;font-size:13px">${T('mission_resets')}</p>`);
      $$('button[data-i]', m.body).forEach((b) => (b.onclick = async () => { try { const r = await API.missionClaim(+b.dataset.i); setProfile(r.profile); flyCoins(b, 6); SFX.coin(); draw(); } catch (e) { toast(T('toast_err'), 'bad'); } }));
      const c = $('#chest', m.body); if (c) c.onclick = async () => { try { const r = await API.chestClaim(); setProfile(r.profile); confetti(1600); flyCoins(c, 12); draw(); } catch (e) {} };
    };
    draw();
  }

  /* =================== shop =================== */
  function grantText(g) {
    const a = [];
    if (g.coins) a.push(`${ic('coin')} ${fmt(g.coins)}`);
    if (g.gems) a.push(`${ic('gem')} ${fmt(g.gems)}`);
    if (g.props) for (const [k, v] of Object.entries(g.props)) a.push(`${ic(propIcon[k])}×${v}`);
    return a.join(' &nbsp; ');
  }
  const prodIcon = (pr) => (pr.id === 'adfree' ? 'noads' : pr.id === 'pro' ? 'crown' : pr.id === 'starter' ? 'chest' : pr.group === 'packs' ? 'gem' : 'coin');
  function openShop(tab) {
    const m = modal({ title: `${T('shop_title')}<span class="gembadge">${ic('gem')}<b id="shop-gems">${fmt(S.profile.gems)}</b></span>`, cls: 'wide', body: '' });
    const tabsEl = html(`<div class="tabs"></div>`); $('.tabs-slot', m.el).appendChild(tabsEl);
    const TABS = [['coins', 'tab_gold'], ['packs', 'tab_packs'], ['special', 'tab_special']];
    let cur = tab || 'coins';
    const draw = () => {
      tabsEl.innerHTML = TABS.map(([id, k]) => `<button data-t="${id}" class="${id === cur ? 'on' : ''}">${T(k)}</button>`).join('');
      $$('button', tabsEl).forEach((b) => (b.onclick = () => { SFX.click(); cur = b.dataset.t; draw(); }));
      const p = S.profile; const prods = S.config.products.filter((x) => x.group === cur);
      let h = prods.map((pr) => {
        const owned = (pr.oneTime && p.oneTime.includes(pr.id)) || (pr.id === 'pro' && p.pro) || (pr.id === 'adfree' && p.adFree);
        const special = cur === 'special';
        const title = pr.title[I18N.lang] || pr.title.en, sub = pr.sub ? (pr.sub[I18N.lang] || pr.sub.en) : '', desc = pr.desc ? (pr.desc[I18N.lang] || pr.desc.en) : '';
        const tag = pr.badge === 'popular' ? `<span class="tag">${I18N.lang === 'tr' ? 'POPÜLER' : 'POPULAR'}</span>` : pr.badge === 'value' ? `<span class="tag gold">${I18N.lang === 'tr' ? 'AVANTAJ' : 'BEST VALUE'}</span>` : pr.badge === 'once' ? `<span class="tag">${I18N.lang === 'tr' ? 'TEK SEFER' : 'ONE-TIME'}</span>` : '';
        const extra = pr.group === 'packs' && pr.id === 'starter' ? `<small class="mut">${grantText(pr.grant)}</small>` : '';
        return `<div class="prow ${special ? 'special' : ''} ${pr.id === 'pro' ? 'gold' : ''}">${tag}<div class="pi">${ic(prodIcon(pr))}</div><div class="pt"><b>${title}</b>${sub ? `<small>${sub}</small>` : ''}${desc ? `<small class="mut">${desc}</small>` : ''}${extra}</div>
          <button class="price" data-pid="${pr.id}" ${owned ? 'disabled' : ''}>${owned ? T('owned') : price(pr)}</button></div>`;
      }).join('');
      if (cur === 'special') {
        h += ['undo', 'hint', 'reorder', 'bay'].map((k) => `<div class="prow"><div class="pi">${ic(propIcon[k])}</div><div class="pt"><b>${propName(k)} <span class="muted">×${p.props[k] || 0}</span></b><small class="mut">${T('prop_' + k + '_d')}</small></div><button class="price" style="background:linear-gradient(#ffe680,#ffa21a);color:#5a3200;box-shadow:inset 0 2px 0 rgba(255,255,255,.6),0 3px 0 #b86a00" data-prop="${k}">${ic('coin')} ${fmt(S.config.propPrice[k])}</button></div>`).join('');
      }
      m.setBody(h);
      const sg = $('#shop-gems', m.el); if (sg) sg.textContent = fmt(S.profile.gems);
      $$('button[data-pid]', m.body).forEach((b) => (b.onclick = async () => {
        const pr = S.config.products.find((x) => x.id === b.dataset.pid);
        const ok = await payment(pr, price(pr)); if (!ok) return;
        try { const r = await API.purchase(pr.id); setProfile(r.profile); SFX.win(); confetti(1500); toast(T('toast_bought'), 'good'); flyCoins(b, 10); draw(); }
        catch (e) { toast(T('toast_err') + ' (' + e.code + ')', 'bad'); }
      }));
      $$('button[data-prop]', m.body).forEach((b) => (b.onclick = async () => {
        const k = b.dataset.prop; if (S.profile.coins < S.config.propPrice[k]) { toast(T('toast_nocoins'), 'bad'); return; }
        try { const r = await API.buyProp(k); setProfile(r.profile); SFX.coin(); draw(); } catch (e) { toast(T('toast_err'), 'bad'); }
      }));
    };
    draw();
  }

  /* =================== Pro =================== */
  function openPro() {
    const pr = S.config.products.find((x) => x.id === 'pro');
    const m = modal({ title: `<span style="color:#ffcf4a">${ic('crown')} ${T('pro_title')}</span>`, cls: 'wide', body: '' });
    const draw = () => {
      const p = S.profile;
      const bus = [0, 4, 5, 2, 1].map((c, i) => ART.busSVG(c, ['neon', 'galaxy', 'aurora', 'gold', 'candy'][i], { filled: 3 })).join('');
      m.setBody(`<p class="sub">${T('pro_sub')}</p><ul class="checks">${[1, 2, 3, 4, 5].map((i) => `<li><i>${ic('check')}</i>${T('pro_b' + i)}</li>`).join('')}</ul>
        <div class="proart">${ic('crown', 'crown')}${bus}</div>`);
      m.foot.innerHTML = ''; m.foot.style.display = '';
      if (p.pro) m.foot.appendChild(html(`<div class="reward-line" style="font-size:22px">${ic('crown')} ${T('pro_active')}</div>`));
      else m.foot.appendChild(btn(`${T('pro_activate')} · ${price(pr)}`, 'orange', async () => {
        const ok = await payment(pr, price(pr)); if (!ok) return;
        try { const r = await API.purchase('pro'); setProfile(r.profile); SFX.win(); confetti(2200); toast(T('toast_bought'), 'good'); draw(); }
        catch (e) { toast(T('toast_err') + ' (' + e.code + ')', 'bad'); }
      }));
    };
    draw();
  }

  /* =================== garage =================== */
  function openGarage() {
    const m = modal({ title: `${T('garage_title')}<span class="gembadge">${ic('gem')}<b id="gar-gems">${fmt(S.profile.gems)}</b></span>`, cls: 'wide', body: '' });
    const draw = () => {
      const p = S.profile, names = ART.SKIN_NAMES[I18N.lang] || ART.SKIN_NAMES.en;
      m.setBody(`<div class="garage-grid">${S.config.skins.map((sk, i) => {
        const owned = p.skins.includes(sk.id), sel = p.skin === sk.id;
        let action;
        if (sel) action = `<button class="btn" disabled>${T('skin_selected')}</button>`;
        else if (owned) action = `<button class="btn green" data-sel="${sk.id}">${T('skin_select')}</button>`;
        else if (sk.pro) action = `<button class="btn orange" data-pro="1">${ic('crown')} ${T('skin_pro')}</button>`;
        else action = `<button class="btn gold" data-buy="${sk.id}">${ic('gem')} ${sk.gems}</button>`;
        return `<div class="skin ${sel ? 'on' : ''}">${!owned ? `<span class="lockbadge">${ic('lock')}</span>` : ''}${ART.busSVG(i % 2 ? 4 : 0, sk.id, { filled: 3 })}<b>${names[sk.id] || sk.id}</b>${action}</div>`;
      }).join('')}</div>`);
      const gg = $('#gar-gems', m.el); if (gg) gg.textContent = fmt(S.profile.gems);
      $$('[data-sel]', m.body).forEach((b) => (b.onclick = async () => { try { const r = await API.skinSelect(b.dataset.sel); setProfile(r.profile, false); SFX.click(); draw(); } catch (e) { toast(T('toast_err'), 'bad'); } }));
      $$('[data-buy]', m.body).forEach((b) => (b.onclick = async () => {
        try { const r = await API.skinBuy(b.dataset.buy); setProfile(r.profile, false); SFX.coin(); confetti(900); draw(); }
        catch (e) { toast(e.code === 'not_enough_gems' ? T('toast_nogems') : T('toast_err'), 'bad'); if (e.code === 'not_enough_gems') { m.close(); openShop('packs'); } }
      }));
      $$('[data-pro]', m.body).forEach((b) => (b.onclick = () => { toast(T('toast_pro_only'), 'bad'); m.close(); openPro(); }));
    };
    draw();
  }

  /* =================== leaderboard =================== */
  async function openRank() {
    const m = modal({ title: T('rank_title'), body: '<div class="muted" style="text-align:center;padding:30px">…</div>' });
    try {
      const r = await API.leaderboard();
      const medal = (i) => (i === 1 ? '🥇' : i === 2 ? '🥈' : i === 3 ? '🥉' : i);
      let h = r.top.map((x) => `<div class="lb-row ${x.me ? 'me' : ''}"><span class="r">${medal(x.rank)}</span><span class="n">${x.pro ? '👑 ' : ''}${x.name.replace(/</g, '&lt;')}</span><span class="l">${T('level')} ${x.level}</span><span class="l">${ic('star')}${x.stars}</span></div>`).join('');
      if (!r.top.some((x) => x.me)) h += `<div class="muted" style="text-align:center">⋯</div><div class="lb-row me"><span class="r">${r.me.rank}</span><span class="n">${T('your_rank')}</span><span class="l">${T('level')} ${r.me.level}</span><span class="l">${ic('star')}${r.me.stars}</span></div>`;
      m.setBody(h || `<div class="muted" style="text-align:center;padding:30px">—</div>`);
    } catch (e) { m.setBody(`<div class="muted" style="text-align:center">${T('toast_err')}</div>`); }
  }

  /* =================== settings =================== */
  function openSettings() {
    const p = S.profile;
    const m = modal({ title: T('settings'), body: '' });
    const draw = () => {
      m.setBody(`<div class="toggle"><span>${T('name')}</span><span style="display:flex;gap:8px;max-width:60%"><input class="field" id="nm" maxlength="16" value="${p.name.replace(/"/g, '')}" style="padding:8px 10px;font-size:16px"><button class="btn green" id="nmsave" style="min-height:42px;padding:0 14px;font-size:15px">${T('save')}</button></span></div>
        <div class="toggle"><span>${T('language')}</span><span class="seg"><button data-l="tr" class="${I18N.lang === 'tr' ? 'on' : ''}">TR</button><button data-l="en" class="${I18N.lang === 'en' ? 'on' : ''}">EN</button></span></div>
        <div class="toggle"><span>${T('sound')}</span><span class="sw ${settings.sound ? 'on' : ''}" data-k="sound"></span></div>
        <div class="toggle"><span>${T('haptics')}</span><span class="sw ${settings.haptics ? 'on' : ''}" data-k="haptics"></span></div>
        <div class="toggle"><span>${T('colorblind')}</span><span class="sw ${settings.cb ? 'on' : ''}" data-k="cb"></span></div>
        <p class="muted" style="font-size:12px;text-align:center;margin:12px 0 0">ID #${p.id} · ${T('privacy')}</p>`);
      $$('.sw', m.body).forEach((s) => (s.onclick = () => { const k = s.dataset.k; settings[k] = !settings[k]; saveSettings(); if (k === 'cb') S.view.setColorblind(settings.cb); SFX.click(); draw(); }));
      $$('.seg button', m.body).forEach((b) => (b.onclick = async () => { localStorage.setItem('nt_lang', b.dataset.l); I18N.setLang(b.dataset.l); try { await API.setProfile({ lang: b.dataset.l }); } catch (e) {} renderHome(); renderDiffLabel(); m.close(); openSettings(); }));
      $('#nmsave', m.body).onclick = async () => { try { const r = await API.setProfile({ name: $('#nm', m.body).value }); setProfile(r.profile); toast(T('toast_got') + ' ✓', 'good'); } catch (e) { toast(T('toast_err'), 'bad'); } };
    };
    draw();
  }

  window.__NT = S;
  window.addEventListener('load', () => boot());
  // stamp every profile assignment (used for client-side countdowns)
  let _p = null;
  Object.defineProperty(S, 'profile', { get() { return _p; }, set(v) { _p = v; S._profileAt = Date.now(); }, configurable: true });
})();
