/* All tunable economy numbers live here. Sent to the client via /api/config. */
const E = require('../shared/engine.js');

const ECONOMY = {
  startCoins: 500,
  startGems: 20,
  startProps: { reorder: 2, bay: 1, vip: 0, hint: 3, undo: 3 },
  propPrice: { reorder: 150, bay: 200, vip: 300, hint: 60, undo: 80 },
  rewardedDailyCap: 24,            // max completed rewarded ads / player / day
  interstitial: { fromLevel: 8, everyWins: 3, minGapSec: 90 },
  ad: {
    minWatchMs: 4000,              // server rejects completions faster than this
    ecpmUsd: 12,                   // only used for the *estimated* ad revenue in the admin panel
    placements: {
      double_reward: {},           // x2 level reward
      revive:        {},           // continue after a loss
      free_prop:     { cap: 6 },
      supply:        { cooldownSec: 1800 },
      spin:          { cap: 3 },
      hint:          {},
    },
  },
  supply: { coins: 40, adMultiplier: 3, cooldownSec: 1800 },
  daily: [                         // 7-day login calendar (day 7 = chest)
    { coins: 100 }, { coins: 200 }, { gems: 5 }, { coins: 300 }, { gems: 10 }, { coins: 500 }, { coins: 1000, gems: 20 },
  ],
  spin: {
    freeEverySec: 86400,
    slices: [
      { id: 0, coins: 50,   w: 24 }, { id: 1, coins: 100, w: 22 }, { id: 2, prop: 'undo', n: 1, w: 14 },
      { id: 3, coins: 200,  w: 14 }, { id: 4, gems: 3, w: 9 }, { id: 5, coins: 500, w: 7 },
      { id: 6, prop: 'hint', n: 2, w: 7 }, { id: 7, gems: 10, w: 3 },
    ],
  },
  levelReward: (n, stars, hard, diff) => Math.round((40 + Math.min(60, Math.floor(n / 2)) + 10 * (stars - 1)) * (hard ? 1.5 : 1) * (E.DIFFS[E.diffOf(diff)].reward)),
  firstClearGems: (n, hard) => (hard ? 3 : n % 5 === 0 ? 2 : 0),
  vipDailyCoins: 250,
  missions: {
    templates: [
      { id: 'deliver', goal: [40, 60, 90], reward: { coins: 120 } },
      { id: 'wins',    goal: [2, 3, 4],    reward: { coins: 150 } },
      { id: 'stars3',  goal: [1, 2],       reward: { gems: 3 } },
      { id: 'deliverColor', goal: [18, 24], reward: { coins: 100 } },
      { id: 'noprops', goal: [1, 2],       reward: { prop: 'undo', n: 1 } },
    ],
    chest: { coins: 300, gems: 5 },
  },
  /* garage: bus skins. gems = price, pro = Pro members only (all skins are free for Pro) */
  skins: [
    { id: 'neon',    gems: 0 },
    { id: 'classic', gems: 0 },
    { id: 'glass',   gems: 25 },
    { id: 'candy',   gems: 40 },
    { id: 'gold',    gems: 60 },
    { id: 'galaxy',  pro: true },
    { id: 'aurora',  pro: true },
  ],
  // price in USD cents (stats only). `tl` = Turkish lira price in kuruş shown to TR players. `grant` is applied server-side after a (verified) purchase.
  products: [
    { id: 'coins_s',   cents: 149,  tl: 4999,  grant: { coins: 200 },  title: { tr: '200 Altın', en: '200 Coins' }, group: 'coins' },
    { id: 'coins_m',   cents: 399,  tl: 12999, grant: { coins: 600 },  title: { tr: '600 Altın', en: '600 Coins' }, sub: { tr: '%10 Bonus', en: '10% Bonus' }, group: 'coins' },
    { id: 'coins_l',   cents: 899,  tl: 29999, grant: { coins: 1500 }, title: { tr: '1.500 Altın', en: '1,500 Coins' }, sub: { tr: '%20 Bonus', en: '20% Bonus' }, badge: 'popular', group: 'coins' },
    { id: 'coins_xl',  cents: 1799, tl: 59999, grant: { coins: 3500 }, title: { tr: '3.500 Altın', en: '3,500 Coins' }, sub: { tr: '%30 Bonus', en: '30% Bonus' }, badge: 'value', group: 'coins' },
    { id: 'gems_s',    cents: 149,  tl: 4999,  grant: { gems: 50 },    title: { tr: '50 Elmas', en: '50 Gems' }, group: 'packs' },
    { id: 'gems_m',    cents: 299,  tl: 9999,  grant: { gems: 130 },   title: { tr: '130 Elmas', en: '130 Gems' }, sub: { tr: '%30 Bonus', en: '30% Bonus' }, badge: 'popular', group: 'packs' },
    { id: 'gems_l',    cents: 599,  tl: 19999, grant: { gems: 300 },   title: { tr: '300 Elmas', en: '300 Gems' }, sub: { tr: '%50 Bonus', en: '50% Bonus' }, badge: 'value', group: 'packs' },
    { id: 'starter',   cents: 199,  tl: 6999,  grant: { coins: 1500, gems: 10, props: { reorder: 3, undo: 5, hint: 5 } }, oneTime: true, title: { tr: 'Başlangıç Paketi', en: 'Starter Bundle' }, sub: { tr: 'Tek seferlik', en: 'One-time' }, badge: 'once', group: 'packs' },
    { id: 'adfree',    cents: 249,  tl: 7999,  grant: { adFree: true }, title: { tr: 'Reklam Kaldır', en: 'Remove Ads' }, desc: { tr: 'Reklamları tamamen kaldır!', en: 'Removes all forced ads!' }, group: 'special' },
    { id: 'pro',       cents: 449,  tl: 14999, grant: { pro: true, adFree: true, coins: 2000, gems: 30 }, oneTime: true, title: { tr: 'Pro Paket', en: 'Pro Pack' }, desc: { tr: 'Tüm özel özellikler + özel otobüs skinleri', en: 'All premium features + exclusive bus skins' }, group: 'special' },
  ],
};

function product(id) { return ECONOMY.products.find((p) => p.id === id); }

function weightedPick(slices, rnd) {
  const tot = slices.reduce((a, s) => a + s.w, 0);
  let r = rnd() * tot;
  for (const s of slices) { r -= s.w; if (r <= 0) return s; }
  return slices[0];
}

/** deterministic daily missions per player + UTC day */
function missionsFor(playerId, dayKey) {
  const rnd = E.mulberry32(Number(playerId) * 977 + Number(dayKey.replace(/-/g, '')));
  const pool = ECONOMY.missions.templates.slice();
  const picked = [];
  while (picked.length < 3) {
    const t = pool.splice(Math.floor(rnd() * pool.length), 1)[0];
    const goal = t.goal[Math.floor(rnd() * t.goal.length)];
    const m = { id: t.id, goal, progress: 0, claimed: false, reward: t.reward };
    if (t.id === 'deliverColor') m.color = Math.floor(rnd() * 4);
    picked.push(m);
  }
  return picked;
}

module.exports = { ECONOMY, product, weightedPick, missionsFor };
